// ============================================
// TOLX. — Main JavaScript
// ============================================

// Progressive enhancement gate: mark that JS is running so the CSS will
// hide .fade-in elements for the scroll animation. If this line never runs
// (JS blocked/errored), .fade-in stays visible by default — no blank sections.
document.documentElement.classList.add('js');

// Scroll fade-in observer
const observer = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.classList.add('visible');
    }
  });
}, { threshold: 0.1, rootMargin: '0px 0px -40px 0px' });

document.querySelectorAll('.fade-in').forEach(el => observer.observe(el));

// Safety net: if anything is still hidden a few seconds after load (observer
// missed it, element taller than viewport, mobile throttling), reveal it.
window.addEventListener('load', () => {
  setTimeout(() => {
    document.querySelectorAll('.fade-in:not(.visible)').forEach(el => {
      const r = el.getBoundingClientRect();
      // Reveal anything at or above the current fold that never triggered.
      if (r.top < window.innerHeight) el.classList.add('visible');
    });
  }, 1200);
});

// Word flip width calculation
function setFlipWidth() {
  document.querySelectorAll('.flip-wrapper').forEach(wrapper => {
    const sizer = wrapper.querySelector('.flip-sizer');
    const words = wrapper.querySelectorAll('.flip-word');
    if (!sizer) return;
    let maxW = sizer.offsetWidth;
    words.forEach(w => {
      w.style.position = 'absolute';
      w.style.visibility = 'hidden';
      w.style.display = 'inline';
      w.style.opacity = '1';
      const wW = w.offsetWidth;
      if (wW > maxW) maxW = wW;
      w.style.position = '';
      w.style.visibility = '';
      w.style.display = '';
      w.style.opacity = '';
    });
    wrapper.style.width = maxW + 'px';
  });
}

// The hidden .flip-sizer already reserves the width in CSS; the measurement only
// refines it, so run it after load instead of during first render (it forces layout).
if (document.querySelector('.flip-wrapper')) {
  window.addEventListener('load', () => requestAnimationFrame(setFlipWidth));
  window.addEventListener('resize', setFlipWidth);
}

// Mobile menu toggle
const mobileToggle = document.querySelector('.nav-mobile-toggle');
const mobileMenu = document.querySelector('.nav-mobile');

if (mobileToggle && mobileMenu) {
  const setMenuState = (open) => {
    mobileMenu.classList.toggle('open', open);
    mobileToggle.setAttribute('aria-expanded', open ? 'true' : 'false');
    document.body.classList.toggle('menu-open', open);
    const spans = mobileToggle.querySelectorAll('span');
    if (open) {
      spans[0].style.transform = 'rotate(45deg) translate(5px, 5px)';
      spans[1].style.opacity = '0';
      spans[2].style.transform = 'rotate(-45deg) translate(5px, -5px)';
    } else {
      spans[0].style.transform = '';
      spans[1].style.opacity = '';
      spans[2].style.transform = '';
    }
  };

  mobileToggle.addEventListener('click', () => {
    setMenuState(!mobileMenu.classList.contains('open'));
  });

  // Close menu when a link inside it is tapped
  mobileMenu.querySelectorAll('a').forEach(link => {
    link.addEventListener('click', () => setMenuState(false));
  });

  // Close on Escape key
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && mobileMenu.classList.contains('open')) {
      setMenuState(false);
    }
  });
}

// Nav scroll state
const navEl = document.querySelector('.nav');
if (navEl) {
  let ticking = false;
  const updateNav = () => {
    if (window.scrollY > 24) {
      navEl.classList.add('scrolled');
    } else {
      navEl.classList.remove('scrolled');
    }
    ticking = false;
  };
  window.addEventListener('scroll', () => {
    if (!ticking) {
      window.requestAnimationFrame(updateNav);
      ticking = true;
    }
  }, { passive: true });
  updateNav();
}

// Pause the hero's looping effects while it is off screen (saves battery/CPU)
const heroEl = document.querySelector('.hero');
if (heroEl && 'IntersectionObserver' in window) {
  new IntersectionObserver((entries) => {
    entries.forEach(entry => heroEl.classList.toggle('fx-paused', !entry.isIntersecting));
  }).observe(heroEl);
}

// Scroll progress hairline
const progressEl = document.querySelector('.scroll-progress');
if (progressEl) {
  let pTick = false;
  const updateProgress = () => {
    const max = document.documentElement.scrollHeight - window.innerHeight;
    progressEl.style.setProperty('--p', max > 0 ? Math.min(1, window.scrollY / max) : 0);
    pTick = false;
  };
  window.addEventListener('scroll', () => {
    if (!pTick) { window.requestAnimationFrame(updateProgress); pTick = true; }
  }, { passive: true });
  updateProgress();
}

// Card spotlight + HUD corners: mark card components and track the pointer
// (fine pointers only, so touch devices don't get a stuck highlight).
const fxSelector = '.card, .diag-card, .sol-card, .op-block, .value-card, .step-card, .module-card, .blog-card, .pricing-card';
document.querySelectorAll(fxSelector).forEach(el => el.classList.add('fx-card'));
if (window.matchMedia('(pointer: fine)').matches) {
  document.addEventListener('pointermove', (e) => {
    const card = e.target.closest('.fx-card');
    if (!card) return;
    const r = card.getBoundingClientRect();
    card.style.setProperty('--mx', (e.clientX - r.left) + 'px');
    card.style.setProperty('--my', (e.clientY - r.top) + 'px');
  }, { passive: true });
}

// Cookie banner: hide document links that render with no text (e.g. the
// cookie-policy link before that page is set up in the consent plugin).
// An empty link is announced as nothing by screen readers and AI agents.
(function () {
  const fixEmptyLinks = () => {
    document.querySelectorAll('.cmplz-documents a, .cmplz-links a').forEach(a => {
      const box = a.closest('li') || a;
      const empty = !a.textContent.trim() && !a.getAttribute('aria-label') && !a.querySelector('img[alt]:not([alt=""])');
      if (empty && !a.dataset.tolxHidden) {
        box.style.display = 'none';
        a.setAttribute('aria-hidden', 'true');
        a.setAttribute('tabindex', '-1');
        a.dataset.tolxHidden = '1';
      } else if (!empty && a.dataset.tolxHidden) {   // plugin filled it in later: show it again
        box.style.display = '';
        a.removeAttribute('aria-hidden');
        a.removeAttribute('tabindex');
        delete a.dataset.tolxHidden;
      }
    });
  };
  fixEmptyLinks();
  const mo = new MutationObserver(fixEmptyLinks);
  mo.observe(document.body, { childList: true, subtree: true });
  setTimeout(() => mo.disconnect(), 8000);
})();

// Ad attribution: remember the campaign tags / Google Ads click id from the
// landing URL (for 30 days, in this browser only) so an enquiry made a few
// pages later still says which ad or campaign brought the visitor.
(function () {
  const KEY = 'tolxAttribution';
  const params = new URLSearchParams(location.search);
  const keys = ['utm_source', 'utm_medium', 'utm_campaign', 'utm_term', 'utm_content', 'gclid', 'gbraid', 'wbraid'];
  const found = {};
  keys.forEach(k => { const v = params.get(k); if (v) found[k] = v.slice(0, 120); });
  try {
    if (Object.keys(found).length) {
      found.landing = location.pathname.slice(0, 120);
      localStorage.setItem(KEY, JSON.stringify({ t: Date.now(), v: found }));
    }
  } catch (e) {}
  const form = document.querySelector('form.cform');
  if (!form) return;
  let saved = null;
  try {
    const raw = JSON.parse(localStorage.getItem(KEY) || 'null');
    if (raw && Date.now() - raw.t < 30 * 864e5) saved = raw.v;
  } catch (e) {}
  if (!saved) return;
  const tracking = form.querySelector('input[name="tracking"]');
  const source = form.querySelector('input[name="source"]');
  if (tracking && !tracking.value) tracking.value = Object.entries(saved).map(([k, v]) => k + '=' + v).join('; ');
  if (source && !source.value) {
    const paid = saved.gclid || saved.gbraid || saved.wbraid || /cpc|ppc|paid/i.test(saved.utm_medium || '');
    source.value = paid && /google/i.test(saved.utm_source || 'google') ? 'google-ads' : (saved.utm_source || '');
  }
})();

// Contact form: inline checks for the two required fields, one submit only.
(function () {
  const form = document.querySelector('form.cform');
  if (!form) return;
  const rules = [
    { el: form.querySelector('#name'), ok: v => v.trim().length > 0, msg: 'Please add your name.' },
    { el: form.querySelector('#email'), ok: v => /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v.trim()), msg: 'Please add a valid email, like name@company.com.' },
    { el: form.querySelector('#privacy_consent'), ok: (v, el) => el.checked, msg: 'Please tick the box to agree to our privacy policy.', box: true },
  ].filter(r => r.el);
  const host = r => r.box ? r.el.closest('.cform-consent-wrap') : r.el.parentNode;
  const show = (r, bad) => {
    let m = host(r).querySelector('.cform-field-msg');
    if (bad) {
      r.el.setAttribute('aria-invalid', 'true');
      if (!m) { m = document.createElement('p'); m.className = 'cform-field-msg'; m.id = r.el.id + '-msg'; host(r).appendChild(m); r.el.setAttribute('aria-describedby', m.id); }
      m.textContent = r.msg;
    } else {
      r.el.removeAttribute('aria-invalid');
      if (m) m.remove();
    }
  };
  rules.forEach(r => { if (!r.box) r.el.addEventListener('blur', () => { if (r.el.value) show(r, !r.ok(r.el.value, r.el)); }); });
  rules.forEach(r => r.el.addEventListener(r.box ? 'change' : 'input', () => { if (r.el.getAttribute('aria-invalid')) show(r, !r.ok(r.el.value, r.el)); }));
  form.addEventListener('submit', (e) => {
    let first = null;
    rules.forEach(r => { const bad = !r.ok(r.el.value, r.el); show(r, bad); if (bad && !first) first = r.el; });
    if (first) { e.preventDefault(); first.focus(); return; }
    const btn = form.querySelector('.cform-submit');
    if (btn) { btn.disabled = true; btn.textContent = 'Sending…'; }
  });
})();

// Consent manager / analytics adapter must explicitly enable this bridge.
window.tolxMeasure = function (event) {
  if (!['enquiry_saved', 'assessment_saved', 'whatsapp_click', 'phone_click'].includes(event)) return;
  if (window.TOLX_ANALYTICS_CONSENT !== true || typeof window.TOLX_ANALYTICS_SEND !== 'function') return;
  window.TOLX_ANALYTICS_SEND(event, {source: 'tolx_theme'});
};
document.addEventListener('click', function (e) {
  var a = e.target.closest('a[href]'); if (!a) return;
  if (/^https:\/\/wa.me\//.test(a.href)) window.tolxMeasure('whatsapp_click');
  else if (/^tel:/.test(a.getAttribute('href'))) window.tolxMeasure('phone_click');
});
